#!/bin/bash

sudo service mongodb start
