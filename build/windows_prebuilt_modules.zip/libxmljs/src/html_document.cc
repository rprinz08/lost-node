// Copyright 2009, Squish Tech, LLC.
#include "html_document.h"

namespace libxmljs {

void
HtmlDocument::Initialize(v8::Handle<v8::Object> target) {
}
}  // namespcae libxmljs
